// 캐시 버전을 변경하면 기존 캐시가 무효화됩니다.
// 코드 수정 후 반드시 이 버전을 올려주세요. (v1 -> v3)
const CACHE_NAME = 'ecoschool-v3';
const ASSETS = [
  '/',
  '/index.html',
  '/icon.svg',
  '/manifest.json'
];

self.addEventListener('install', (e) => {
  // 새 SW가 설치되면 즉시 활성화 대기 상태에서 벗어남
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
});

self.addEventListener('activate', (e) => {
  // 활성화 시 옛 캐시 모두 삭제
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;

  // GET 요청만 처리
  if (req.method !== 'GET') return;

  const url = new URL(req.url);

  // HTML 문서(네비게이션)와 JS/CSS는 항상 네트워크 우선 - 최신 코드를 반드시 받도록
  const isNavigation = req.mode === 'navigate';
  const isAsset = /\.(?:js|css|mjs)$/.test(url.pathname);

  if (isNavigation || isAsset) {
    e.respondWith(
      fetch(req)
        .then((res) => {
          // 성공 시 캐시 갱신
          const resClone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone)).catch(() => {});
          return res;
        })
        .catch(() => caches.match(req).then((cached) => cached || caches.match('/index.html')))
    );
    return;
  }

  // 그 외 정적 자원은 캐시 우선 (이미지, 아이콘 등)
  e.respondWith(
    caches.match(req).then((cached) => cached || fetch(req))
  );
});
